# AimX

Head-level aim-training assistant for Android (Kotlin + Jetpack Compose).
It passively reads your screen (with your MediaProjection consent), shows whether your crosshair is
**above / aligned / below** the estimated head level, and tracks accuracy, reaction time and consistency.
It never injects input, touches game memory, or automates aiming. See [PRIVACY.md](PRIVACY.md).

## Features
- Live analysis with a draggable floating pill (tap to pause/resume) and a foreground notification with Pause/Stop.
- **Head-Level Drill**: a built-in practice mode that works without any game (10 targets, reaction time, bias).
- Head-Level Coach, Aim Statistics, Sensitivity Recommendations, Training History, Settings and calibration.
- Local-only storage, no internet permission.

## Get the APK without Android Studio
1. Push this repo to GitHub.
2. Open the **Actions** tab, then the latest *Android CI* run, and download the **AimX-debug-apk** artifact.
3. Unzip it and install `app-debug.apk` on your phone (allow "Install unknown apps").

To publish a release, tag a commit: `git tag v1.0 && git push origin v1.0`. The APK is attached to the release.

## Build locally
Requires JDK 17 and Android Studio (Ladybug or newer).
```
gradle wrapper --gradle-version 8.9   # once, creates ./gradlew
./gradlew testDebugUnitTest assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Use
Start Analysis, allow "Display over other apps" and the screen-capture prompt, then open the game.
Detection is heuristic (it looks for the red enemy marker bar). Calibrate in Settings: *Head offset*,
*Crosshair vertical shift*, *Aligned tolerance*. The Drill needs no calibration.

## Layout
`capture/` MediaProjection foreground service · `analysis/` detector, engine, recommender ·
`overlay/` floating pill · `data/` local store · `ui/` Compose screens and the drill.

## Notes
Games may prohibit third-party tools during matches. Use AimX for training, at your own risk. MIT licensed.
