package com.aimx.analysis

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class HeadLevel { NONE, ABOVE, ALIGNED, BELOW }

/** Enemy marker (name/health bar) found in analysis-pixel coordinates. */
data class Detection(val cx: Float, val barBottom: Float, val barWidth: Float)

/** offset: crosshair relative to head centre in bar-widths. +ve = crosshair below head. */
data class FrameResult(val level: HeadLevel, val offset: Float)

data class AimSettings(
    val tolerance: Float = 0.30f,   // aligned band, in bar-widths
    val headOffset: Float = 0.40f,  // head centre below bar bottom, in bar-widths
    val crosshairY: Float = 0f,     // crosshair vertical shift from screen centre (fraction of height)
    val fps: Int = 10,              // analysis rate (lower = less battery)
    val overlay: Boolean = true,
    val drillSens: Float = 1f       // drag sensitivity multiplier in the built-in drill
)

data class SessionSummary(
    val startTime: Long, val durationMs: Long, val samples: Int,
    val alignedPct: Float, val abovePct: Float, val belowPct: Float,
    val avgReactionMs: Float, val consistency: Float, val bias: Float,
    val drill: Boolean = false
)

/** Collects metrics for one training session. */
class AimEngine(private val s: AimSettings) {
    val startTime = System.currentTimeMillis()
    private var samples = 0; private var aligned = 0; private var above = 0; private var below = 0
    private var sum = 0.0; private var sumSq = 0.0
    private var reactionSum = 0L; private var reactionN = 0
    private var appearedAt = -1L; private var lastSeen = -1L; private var reacted = false

    val alignedPct get() = if (samples == 0) 0 else (aligned * 100f / samples).roundToInt()
    val avgReaction get() = if (reactionN == 0) 0 else (reactionSum / reactionN).toInt()

    fun onFrame(det: Detection?, cx: Float, cy: Float, now: Long): FrameResult {
        if (det == null) {
            if (appearedAt >= 0 && now - lastSeen > 400) { appearedAt = -1; reacted = false }
            return FrameResult(HeadLevel.NONE, 0f)
        }
        if (appearedAt < 0) { appearedAt = now; reacted = false }
        lastSeen = now
        val headY = det.barBottom + s.headOffset * det.barWidth
        val off = (cy - headY) / det.barWidth
        if (abs(cx - det.cx) > det.barWidth) return FrameResult(HeadLevel.NONE, off) // not on target horizontally
        val level = when {
            off < -s.tolerance -> HeadLevel.ABOVE
            off > s.tolerance -> HeadLevel.BELOW
            else -> HeadLevel.ALIGNED
        }
        samples++; sum += off; sumSq += off * off
        when (level) { HeadLevel.ABOVE -> above++; HeadLevel.BELOW -> below++; else -> aligned++ }
        if (level == HeadLevel.ALIGNED && !reacted) { reacted = true; reactionSum += now - appearedAt; reactionN++ }
        return FrameResult(level, off)
    }

    fun summary(): SessionSummary {
        val n = max(samples, 1)
        val mean = (sum / n).toFloat()
        val sd = sqrt(max(0.0, sumSq / n - (sum / n) * (sum / n))).toFloat()
        return SessionSummary(startTime, System.currentTimeMillis() - startTime, samples,
            aligned * 100f / n, above * 100f / n, below * 100f / n,
            if (reactionN == 0) 0f else reactionSum.toFloat() / reactionN, sd, mean)
    }
}

data class Advice(val enoughData: Boolean, val changePct: Int, val tips: List<String>)

/** Personalised sensitivity guidance from recent sessions (heuristic starting point, not a guarantee). */
object Recommender {
    fun advise(all: List<SessionSummary>): Advice {
        val r = all.takeLast(10).filter { it.samples >= 20 }
        val total = r.sumOf { it.samples }
        if (total < 100) return Advice(false, 0, listOf("Not enough data yet. Train until you have ~100 evaluated frames (a few sessions)."))
        fun w(f: (SessionSummary) -> Float) = r.sumOf { (f(it) * it.samples).toDouble() }.toFloat() / total
        val above = w { it.abovePct }; val below = w { it.belowPct }; val aligned = w { it.alignedPct }
        val sd = w { it.consistency }
        val rt = r.filter { it.avgReactionMs > 0 }.let { l -> if (l.isEmpty()) 0f else l.map { it.avgReactionMs }.average().toFloat() }
        val diff = above - below
        val change = when {
            diff > 15 -> -min(15f, diff / 4f)
            diff < -15 -> min(15f, -diff / 4f)
            else -> 0f
        }.roundToInt()
        val tips = mutableListOf<String>()
        when {
            change < 0 -> tips += "You overshoot above the head. Lower general + red-dot/scope sensitivity by about ${-change}% and re-test."
            change > 0 -> tips += "You stop below the head. Raise sensitivity by about $change% or drag slightly further."
            else -> tips += "Vertical bias is balanced. Keep your current sensitivity."
        }
        if (sd > 0.5f) tips += "Aim consistency is low. Use the same drag length and thumb start position every time."
        if (rt > 700f) tips += "Reaction time is slow (${rt.roundToInt()} ms). Keep the crosshair at head height while moving."
        if (aligned >= 70f) tips += "Head-level accuracy is strong (${aligned.roundToInt()}%). Increase difficulty."
        return Advice(true, change, tips)
    }
}
