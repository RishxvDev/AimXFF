package com.aimx.analysis

import java.nio.ByteBuffer
import kotlin.math.abs

/**
 * Lightweight, allocation-free detector. Looks for bar-shaped red regions (enemy health/name
 * markers) in the central part of an RGBA frame and returns the one nearest the crosshair.
 * Heuristic by design; swap for a TFLite model by implementing the same signature.
 */
class EnemyDetector {
    private var mask = BooleanArray(0)
    private var queue = IntArray(0)

    fun detect(buf: ByteBuffer, stride: Int, w: Int, h: Int, crossX: Int): Detection? {
        val x0 = (w * 0.2f).toInt(); val x1 = (w * 0.8f).toInt()
        val y0 = (h * 0.08f).toInt(); val y1 = (h * 0.92f).toInt()
        val rw = x1 - x0; val rh = y1 - y0
        if (mask.size != rw * rh) { mask = BooleanArray(rw * rh); queue = IntArray(rw * rh) }
        for (y in 0 until rh) {
            val row = (y + y0) * stride
            for (x in 0 until rw) {
                val i = row + (x + x0) * 4
                val r = buf.get(i).toInt() and 255
                val g = buf.get(i + 1).toInt() and 255
                val b = buf.get(i + 2).toInt() and 255
                mask[y * rw + x] = r > 190 && g < 80 && b < 80
            }
        }
        var best: Detection? = null
        var bestD = Float.MAX_VALUE
        for (s in mask.indices) {
            if (!mask[s]) continue
            var head = 0; var tail = 0
            queue[tail++] = s; mask[s] = false
            var minX = rw; var maxX = -1; var minY = rh; var maxY = -1; var n = 0
            while (head < tail) {
                val p = queue[head++]; val px = p % rw; val py = p / rw; n++
                if (px < minX) minX = px
                if (px > maxX) maxX = px
                if (py < minY) minY = py
                if (py > maxY) maxY = py
                if (px > 0 && mask[p - 1]) { mask[p - 1] = false; queue[tail++] = p - 1 }
                if (px < rw - 1 && mask[p + 1]) { mask[p + 1] = false; queue[tail++] = p + 1 }
                if (py > 0 && mask[p - rw]) { mask[p - rw] = false; queue[tail++] = p - rw }
                if (py < rh - 1 && mask[p + rw]) { mask[p + rw] = false; queue[tail++] = p + rw }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            if (n >= 8 && bw >= 10 && bw >= bh * 2.5f) {
                val cx = x0 + (minX + maxX) / 2f
                val d = abs(cx - crossX)
                if (d < bestD) { bestD = d; best = Detection(cx, (y0 + maxY).toFloat(), bw.toFloat()) }
            }
        }
        return best
    }
}
