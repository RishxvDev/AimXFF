package com.aimx.ui

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimx.analysis.SessionSummary
import com.aimx.data.Store
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.random.Random

private enum class DrillPhase { Ready, Waiting, Target, Done }

private const val ROUNDS = 10
private const val ALIGNED_BAND = 0.5f // head-level band, in head diameters either side of head centre

/**
 * Built-in practice drill. Works without any game: a target appears at a random spot, the player drags
 * to move the crosshair onto its head and taps FIRE. Measures reaction time, above/below/aligned bias
 * and consistency, then saves a numeric session summary like a live session would.
 */
@Composable
fun Drill() {
    val ctx = LocalContext.current
    var sens by remember { mutableFloatStateOf(Store.settings(ctx).drillSens) }
    var phase by remember { mutableStateOf(DrillPhase.Ready) }
    var round by remember { mutableIntStateOf(0) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var crossX by remember { mutableFloatStateOf(0f) }
    var crossY by remember { mutableFloatStateOf(0f) }
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var headR by remember { mutableFloatStateOf(30f) }
    var shownAt by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var misses by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("Press START. When a target appears, drag to put the crosshair on its head, then tap FIRE.") }
    var summary by remember { mutableStateOf<SessionSummary?>(null) }
    var saved by remember { mutableStateOf(false) }
    val offsets = remember { mutableStateListOf<Float>() }
    val reactions = remember { mutableStateListOf<Long>() }

    fun finish() {
        val n = offsets.size
        if (n > 0) {
            val mean = offsets.sum() / n
            val sd = sqrt(offsets.map { (it - mean) * (it - mean) }.sum() / n)
            val s = SessionSummary(
                startedAt, System.currentTimeMillis() - startedAt, n,
                offsets.count { abs(it) <= ALIGNED_BAND } * 100f / n,
                offsets.count { it < -ALIGNED_BAND } * 100f / n,
                offsets.count { it > ALIGNED_BAND } * 100f / n,
                reactions.average().toFloat(), sd, mean, drill = true
            )
            Store.add(ctx, s) // ignores sessions with fewer than 5 hits
            saved = n >= 5
            summary = s
        } else summary = null
        phase = DrillPhase.Done
    }

    fun start() {
        offsets.clear(); reactions.clear()
        misses = 0; round = 0; summary = null; saved = false
        startedAt = System.currentTimeMillis()
        message = "Get ready…"
        phase = DrillPhase.Waiting
    }

    fun fire() {
        when (phase) {
            DrillPhase.Waiting -> message = "Too early. Wait for the target."
            DrillPhase.Target -> {
                val dx = crossX - tx
                val dy = crossY - ty
                if (abs(dx) <= headR * 1.6f) {
                    val off = dy / (2 * headR)
                    val rt = SystemClock.elapsedRealtime() - shownAt
                    offsets.add(off); reactions.add(rt)
                    message = when {
                        off < -ALIGNED_BAND -> "▲ Above the head"
                        off > ALIGNED_BAND -> "▼ Below the head"
                        else -> "● Head level"
                    } + "  ·  $rt ms"
                } else {
                    misses++
                    message = "Missed sideways"
                }
                round++
                if (round >= ROUNDS) finish() else phase = DrillPhase.Waiting
            }
            else -> Unit
        }
    }

    LaunchedEffect(phase, round) {
        if (phase != DrillPhase.Waiting) return@LaunchedEffect
        delay(Random.nextLong(600, 1500))
        val w = area.width.toFloat()
        val h = area.height.toFloat()
        if (w <= 0f || h <= 0f) return@LaunchedEffect
        headR = min(w, h) * 0.055f
        crossX = w / 2; crossY = h / 2
        var x = w / 2; var y = h * 0.3f
        var tries = 0
        do {
            x = w * (0.15f + 0.7f * Random.nextFloat())
            y = h * (0.2f + 0.55f * Random.nextFloat())
            tries++
        } while (tries < 20 && hypot(x - crossX, y - crossY) < min(w, h) * 0.25f)
        tx = x; ty = y
        shownAt = SystemClock.elapsedRealtime()
        phase = DrillPhase.Target
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Target ${min(round + 1, ROUNDS)} / $ROUNDS  ·  $misses missed", color = Muted, fontSize = 13.sp)
        Box(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel)
                .onSizeChanged { area = it }
                .pointerInput(phase, sens) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        if (phase == DrillPhase.Target) {
                            crossX = (crossX + drag.x * sens).coerceIn(0f, area.width.toFloat())
                            crossY = (crossY + drag.y * sens).coerceIn(0f, area.height.toFloat())
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                if (phase == DrillPhase.Target) {
                    drawCircle(Red, headR, Offset(tx, ty))
                    drawRoundRect(
                        Color(0xFF3A3A3A), Offset(tx - headR * 1.6f, ty + headR * 1.1f),
                        Size(headR * 3.2f, headR * 5f), CornerRadius(headR * 0.6f)
                    )
                }
                if (phase == DrillPhase.Waiting || phase == DrillPhase.Target) {
                    val cx = if (phase == DrillPhase.Target) crossX else size.width / 2
                    val cy = if (phase == DrillPhase.Target) crossY else size.height / 2
                    drawLine(Color.White, Offset(cx - 22f, cy), Offset(cx + 22f, cy), 3f)
                    drawLine(Color.White, Offset(cx, cy - 22f), Offset(cx, cy + 22f), 3f)
                }
            }
            if (phase == DrillPhase.Ready) {
                Text(
                    "10 targets · drag to aim · tap FIRE\nNo game needed. Great for warming up.",
                    Modifier.align(Alignment.Center).padding(24.dp), color = Muted
                )
            }
            if (phase == DrillPhase.Done) {
                val s = summary
                Column(Modifier.align(Alignment.Center).padding(24.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (s == null) {
                        Text("No hits recorded. Try again.", color = Muted)
                    } else {
                        Text("${s.alignedPct.roundToInt()}% head level", fontSize = 28.sp, fontWeight = FontWeight.Black)
                        Text("Above ${s.abovePct.roundToInt()}%  ·  Below ${s.belowPct.roundToInt()}%", color = Muted)
                        Text("Avg reaction ${s.avgReactionMs.roundToInt()} ms  ·  $misses missed", color = Muted)
                        Text(if (saved) "Saved to Training History" else "Too few hits to save (need 5+)", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        Text(message, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Drag sensitivity ×${String.format("%.1f", sens)}", color = Muted, fontSize = 12.sp)
                Slider(
                    sens, { sens = it },
                    onValueChangeFinished = { Store.save(ctx, Store.settings(ctx).copy(drillSens = sens)) },
                    valueRange = 0.5f..2.5f
                )
            }
            Button(
                onClick = { if (phase == DrillPhase.Ready || phase == DrillPhase.Done) start() else fire() },
                modifier = Modifier.width(140.dp).height(56.dp), shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    when (phase) { DrillPhase.Ready -> "START"; DrillPhase.Done -> "AGAIN"; else -> "FIRE" },
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}
