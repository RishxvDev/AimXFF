package com.aimx.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aimx.analysis.*
import com.aimx.data.AimXState
import com.aimx.data.Store
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

enum class Screen(val title: String) {
    Dashboard("AimX"), Coach("Head-Level Coach"), Stats("Aim Statistics"),
    Sens("Sensitivity Recommendations"), Drill("Head-Level Drill"), History("Training History"), Settings("Settings")
}

@Composable
fun AimXApp(onStart: () -> Unit, onStop: () -> Unit, onTogglePause: () -> Unit) {
    var screen by remember { mutableStateOf(Screen.Dashboard) }
    BackHandler(screen != Screen.Dashboard) { screen = Screen.Dashboard }
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            if (screen != Screen.Dashboard) Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { screen = Screen.Dashboard }) { Text("‹ Back", color = Red, fontWeight = FontWeight.Bold) }
                Text(screen.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            AnimatedContent(screen, label = "nav") { s ->
                when (s) {
                    Screen.Dashboard -> Dashboard(onStart, onStop, onTogglePause) { screen = it }
                    Screen.Coach -> Coach()
                    Screen.Stats -> Stats()
                    Screen.Sens -> Sens()
                    Screen.Drill -> Drill()
                    Screen.History -> History()
                    Screen.Settings -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
internal fun Page(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp), content = content
)

@Composable
internal fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) = Column(
    modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel)
        .border(1.dp, Panel2, RoundedCornerShape(18.dp)).padding(16.dp), content = content
)

@Composable
private fun Dashboard(onStart: () -> Unit, onStop: () -> Unit, onTogglePause: () -> Unit, go: (Screen) -> Unit) {
    val running by AimXState.running.collectAsState()
    val paused by AimXState.paused.collectAsState()
    val live by AimXState.live.collectAsState()
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.3f, 1f,
        infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Page {
        Row { Text("AIM", fontSize = 34.sp, fontWeight = FontWeight.Black); Text("X", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Red) }
        Text("Head-level aim training assistant", color = Muted)
        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).alpha(if (running && !paused) pulse else 1f).clip(CircleShape)
                    .background(if (running && !paused) Red else Muted))
                Spacer(Modifier.width(10.dp))
                Text(if (!running) "Idle" else if (paused) "Paused" else "Analysing", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(levelText(live.level), fontSize = 26.sp, fontWeight = FontWeight.Black,
                color = if (live.level == HeadLevel.ALIGNED) Color.White else if (live.level == HeadLevel.NONE) Muted else Red)
            if (running) Text("Session head-level accuracy: ${live.alignedPct}%  ·  reaction ${live.reactionMs} ms", color = Muted, fontSize = 13.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onStart, Modifier.weight(1f).height(52.dp), enabled = !running, shape = RoundedCornerShape(14.dp)) { Text("Start Analysis", fontWeight = FontWeight.Bold) }
            OutlinedButton(onStop, Modifier.weight(1f).height(52.dp), enabled = running, shape = RoundedCornerShape(14.dp)) { Text("Stop Analysis", color = if (running) Color.White else Muted) }
        }
        if (running) OutlinedButton(onTogglePause, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text(if (paused) "Resume analysis" else "Pause analysis") }
        Text("Open Free Fire after starting. Tap the floating pill to pause/resume.", color = Muted, fontSize = 12.sp)
        listOf(Screen.Coach to "Above / below / aligned", Screen.Stats to "Accuracy · reaction · consistency",
            Screen.Sens to "Personalised suggestions", Screen.Drill to "Practice without a game", Screen.History to "Past sessions", Screen.Settings to "Calibration & privacy")
            .chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { (s, sub) ->
                        Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Panel)
                            .border(1.dp, Panel2, RoundedCornerShape(16.dp)).clickable { go(s) }.padding(16.dp)) {
                            Text(s.title, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp))
                            Text(sub, color = Muted, fontSize = 12.sp)
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
    }
}

private fun levelText(l: HeadLevel) = when (l) {
    HeadLevel.ABOVE -> "▲ ABOVE HEAD"; HeadLevel.BELOW -> "▼ BELOW HEAD"
    HeadLevel.ALIGNED -> "● ALIGNED"; HeadLevel.NONE -> "No target"
}

@Composable
private fun Coach() {
    val live by AimXState.live.collectAsState()
    val sessions by AimXState.sessions.collectAsState()
    val target = if (live.level == HeadLevel.NONE) 0f else live.offset.coerceIn(-1.5f, 1.5f)
    val anim by animateFloatAsState(target, spring(stiffness = Spring.StiffnessMedium), label = "off")
    Page {
        Canvas(Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(20.dp)).background(Panel)) {
            val cy = size.height / 2; val half = size.height / 2 - 20f
            val band = half * (0.3f / 1.5f)
            drawRect(Red.copy(alpha = .15f), Offset(0f, cy - band), Size(size.width, band * 2))
            drawLine(Red, Offset(0f, cy), Offset(size.width, cy), 3f)
            val x = size.width / 2; val y = cy + anim / 1.5f * half
            drawCircle(Color.White, 14f, Offset(x, y), style = Stroke(3f))
            drawLine(Color.White, Offset(x - 24, y), Offset(x + 24, y), 3f)
            drawLine(Color.White, Offset(x, y - 24), Offset(x, y + 24), 3f)
        }
        Card {
            Text(levelText(live.level), fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text(when (live.level) {
                HeadLevel.ABOVE -> "Overshooting. Shorten the drag or ease off at the end of the swipe."
                HeadLevel.BELOW -> "Stopping short. Drag a little further up before releasing."
                HeadLevel.ALIGNED -> "On head level. Repeat the same drag length."
                HeadLevel.NONE -> "Start analysis and aim at an enemy marker in training."
            }, color = Muted)
        }
        Card {
            Text("Head-level accuracy over time", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            LineChart(sessions.takeLast(15).map { it.alignedPct })
        }
    }
}

@Composable
private fun LineChart(v: List<Float>) {
    if (v.size < 2) { Text("Complete 2+ sessions to see your trend.", color = Muted, fontSize = 13.sp); return }
    Canvas(Modifier.fillMaxWidth().height(120.dp)) {
        val path = Path()
        v.forEachIndexed { i, y ->
            val px = i * size.width / (v.size - 1); val py = size.height * (1 - y.coerceIn(0f, 100f) / 100f)
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            drawCircle(Red, 5f, Offset(px, py))
        }
        drawPath(path, Red, style = Stroke(4f))
    }
}

@Composable
private fun Stat(label: String, value: String) = Card { Text(label, color = Muted, fontSize = 13.sp); Text(value, fontSize = 30.sp, fontWeight = FontWeight.Black) }

@Composable
private fun Stats() {
    val s by AimXState.sessions.collectAsState()
    val n = s.sumOf { it.samples }
    fun w(f: (SessionSummary) -> Float) = if (n == 0) 0f else s.sumOf { (f(it) * it.samples).toDouble() }.toFloat() / n
    val rs = s.filter { it.avgReactionMs > 0 }
    Page {
        Stat("Head-level accuracy", "${w { it.alignedPct }.roundToInt()}%")
        Stat("Average reaction time", if (rs.isEmpty()) "—" else "${rs.map { it.avgReactionMs }.average().roundToInt()} ms")
        Stat("Aim consistency (lower = steadier)", String.format("%.2f", w { it.consistency }))
        Stat("Above / below", "${w { it.abovePct }.roundToInt()}% / ${w { it.belowPct }.roundToInt()}%")
        Stat("Sessions · samples", "${s.size} · $n")
    }
}

@Composable
private fun Sens() {
    val a = Recommender.advise(AimXState.sessions.collectAsState().value)
    Page {
        Card {
            Text("Suggested change", color = Muted, fontSize = 13.sp)
            Text(if (!a.enoughData) "—" else if (a.changePct == 0) "Keep" else "${if (a.changePct > 0) "+" else ""}${a.changePct}%",
                fontSize = 40.sp, fontWeight = FontWeight.Black, color = Red)
        }
        a.tips.forEach { Card { Text(it) } }
        Text("Suggestions are a starting point. Change one setting at a time and re-test.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun History() {
    val s by AimXState.sessions.collectAsState()
    if (s.isEmpty()) { Page { Text("No sessions yet.", color = Muted) }; return }
    val df = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(s.reversed()) {
            Card {
                Text(df.format(Date(it.startTime)) + if (it.drill) "  ·  Drill" else "  ·  Live", fontWeight = FontWeight.Bold)
                Text("${it.alignedPct.roundToInt()}% aligned · ${it.avgReactionMs.roundToInt()} ms · ${it.durationMs / 60000} min · ${it.samples} samples", color = Muted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    val ctx = LocalContext.current
    var cfg by remember { mutableStateOf(Store.settings(ctx)) }
    fun upd(c: AimSettings) { cfg = c; Store.save(ctx, c) }
    Page {
        Card {
            Text("Aligned tolerance: ${String.format("%.2f", cfg.tolerance)}", fontWeight = FontWeight.Bold)
            Slider(cfg.tolerance, { upd(cfg.copy(tolerance = it)) }, valueRange = 0.1f..0.8f)
            Text("Head offset below marker: ${String.format("%.2f", cfg.headOffset)}", fontWeight = FontWeight.Bold)
            Slider(cfg.headOffset, { upd(cfg.copy(headOffset = it)) }, valueRange = 0f..1.2f)
            Text("Crosshair vertical shift: ${String.format("%.2f", cfg.crosshairY)}", fontWeight = FontWeight.Bold)
            Slider(cfg.crosshairY, { upd(cfg.copy(crosshairY = it)) }, valueRange = -0.2f..0.2f)
            Text("Analysis rate: ${cfg.fps} fps (lower saves battery)", fontWeight = FontWeight.Bold)
            Slider(cfg.fps.toFloat(), { upd(cfg.copy(fps = it.roundToInt())) }, valueRange = 3f..20f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Floating indicator", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(cfg.overlay, { upd(cfg.copy(overlay = it)) })
            }
            Text("Changes apply to the next session.", color = Muted, fontSize = 12.sp)
        }
        Card {
            Text("Privacy", fontWeight = FontWeight.Bold)
            Text("Screen frames are analysed in memory on this device and discarded immediately. Only numeric session summaries are stored. AimX never sends data anywhere and never controls or modifies the game.", color = Muted, fontSize = 13.sp)
        }
        OutlinedButton({ Store.clear(ctx) }, Modifier.fillMaxWidth()) { Text("Delete all training data", color = Red) }
    }
}
