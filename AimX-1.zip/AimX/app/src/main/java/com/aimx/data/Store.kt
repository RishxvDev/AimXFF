package com.aimx.data

import android.content.Context
import com.aimx.analysis.AimSettings
import com.aimx.analysis.HeadLevel
import com.aimx.analysis.SessionSummary
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Live(val level: HeadLevel = HeadLevel.NONE, val offset: Float = 0f, val alignedPct: Int = 0, val reactionMs: Int = 0)

/** Shared in-process state between the capture service and the UI. */
object AimXState {
    val running = MutableStateFlow(false)
    val paused = MutableStateFlow(false)
    val live = MutableStateFlow(Live())
    val sessions = MutableStateFlow<List<SessionSummary>>(emptyList())
}

/** Local-only storage. Frames are never saved; only numeric session summaries are. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("aimx", Context.MODE_PRIVATE)

    fun settings(c: Context): AimSettings = p(c).let {
        val d = AimSettings()
        AimSettings(it.getFloat("tol", d.tolerance), it.getFloat("head", d.headOffset),
            it.getFloat("cy", d.crosshairY), it.getInt("fps", d.fps), it.getBoolean("ov", d.overlay),
            it.getFloat("ds", d.drillSens))
    }

    fun save(c: Context, s: AimSettings) = p(c).edit()
        .putFloat("tol", s.tolerance).putFloat("head", s.headOffset).putFloat("cy", s.crosshairY)
        .putInt("fps", s.fps).putBoolean("ov", s.overlay).putFloat("ds", s.drillSens).apply()

    fun sessions(c: Context): List<SessionSummary> = try {
        val a = JSONArray(p(c).getString("sessions", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            SessionSummary(o.getLong("t"), o.getLong("d"), o.getInt("n"), o.getDouble("a").toFloat(),
                o.getDouble("u").toFloat(), o.getDouble("b").toFloat(), o.getDouble("r").toFloat(),
                o.getDouble("c").toFloat(), o.getDouble("m").toFloat(), o.optBoolean("k", false))
        }
    } catch (e: Exception) { emptyList() }

    fun add(c: Context, s: SessionSummary) {
        if (s.samples < 5) return // ignore empty sessions
        val list = (sessions(c) + s).takeLast(100)
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("t", it.startTime).put("d", it.durationMs).put("n", it.samples)
                .put("a", it.alignedPct).put("u", it.abovePct).put("b", it.belowPct)
                .put("r", it.avgReactionMs).put("c", it.consistency).put("m", it.bias).put("k", it.drill))
        }
        p(c).edit().putString("sessions", a.toString()).apply()
        AimXState.sessions.value = list
    }

    fun clear(c: Context) { p(c).edit().remove("sessions").apply(); AimXState.sessions.value = emptyList() }
}
