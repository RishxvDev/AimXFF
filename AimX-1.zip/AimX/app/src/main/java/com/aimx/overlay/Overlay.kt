package com.aimx.overlay

import android.content.Context
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.aimx.analysis.HeadLevel
import kotlin.math.abs

/** Small draggable floating indicator. Tap = pause/resume. Never intercepts game input outside its own bounds. */
class Overlay(private val ctx: Context, private val onTap: () -> Unit) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val view = Pill(ctx)
    private val lp = WindowManager.LayoutParams(
        view.w, view.h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 40; y = 40 }
    private var shown = false

    fun show() { if (!shown) { wm.addView(view, lp); shown = true } }
    fun hide() { if (shown) { runCatching { wm.removeView(view) }; shown = false } }
    fun update(level: HeadLevel, paused: Boolean) { view.level = level; view.paused = paused; view.postInvalidate() }

    private inner class Pill(c: Context) : View(c) {
        var level = HeadLevel.NONE
        var paused = false
        private val d = c.resources.displayMetrics.density
        val w = (150 * d).toInt()
        val h = (40 * d).toInt()
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE60A0A0A.toInt() }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d; color = 0xFFE11D2E.toInt() }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 14 * d; typeface = Typeface.DEFAULT_BOLD; color = Color.WHITE }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        private var dx = 0f; private var dy = 0f; private var sx = 0; private var sy = 0; private var moved = false

        override fun onMeasure(a: Int, b: Int) = setMeasuredDimension(w, h)

        override fun onDraw(cv: Canvas) {
            val r = h / 2f
            cv.drawRoundRect(0f, 0f, w.toFloat(), h.toFloat(), r, r, bg)
            cv.drawRoundRect(1f, 1f, w - 1f, h - 1f, r, r, stroke)
            val (label, col) = when {
                paused -> "PAUSED" to 0xFF888888.toInt()
                level == HeadLevel.ABOVE -> "▲ ABOVE" to 0xFFE11D2E.toInt()
                level == HeadLevel.BELOW -> "▼ BELOW" to 0xFFE11D2E.toInt()
                level == HeadLevel.ALIGNED -> "● ALIGNED" to Color.WHITE
                else -> "AimX · scanning" to 0xFF888888.toInt()
            }
            dot.color = col
            cv.drawCircle(18 * d, h / 2f, 6 * d, dot)
            txt.textSize = if (label.length > 9) 11 * d else 14 * d
            cv.drawText(label, 32 * d, h / 2f + txt.textSize / 3f, txt)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > 12 || abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(this, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap()
            }
            return true
        }
    }
}
