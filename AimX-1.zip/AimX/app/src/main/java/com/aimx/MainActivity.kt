package com.aimx

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.aimx.capture.CaptureService
import com.aimx.data.AimXState
import com.aimx.data.Store
import com.aimx.ui.AimXApp
import com.aimx.ui.AimXTheme

class MainActivity : ComponentActivity() {
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            ContextCompat.startForegroundService(this, Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, r.resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data))
        } else Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AimXState.sessions.value = Store.sessions(this)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            AimXTheme {
                AimXApp(onStart = ::startAnalysis,
                    onStop = { cmd(CaptureService.ACTION_STOP) },
                    onTogglePause = { cmd(if (AimXState.paused.value) CaptureService.ACTION_RESUME else CaptureService.ACTION_PAUSE) })
            }
        }
    }

    private fun cmd(a: String) { startService(Intent(this, CaptureService::class.java).setAction(a)) }

    private fun startAnalysis() {
        if (Store.settings(this).overlay && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps' for the floating indicator, then tap Start again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
