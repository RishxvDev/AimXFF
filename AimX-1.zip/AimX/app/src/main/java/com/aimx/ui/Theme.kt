package com.aimx.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Red = Color(0xFFE11D2E)
val Bg = Color(0xFF0A0A0A)
val Panel = Color(0xFF161616)
val Panel2 = Color(0xFF222222)
val Muted = Color(0xFF8A8A8A)

@Composable
fun AimXTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Red, onPrimary = Color.White, background = Bg, surface = Panel,
        onSurface = Color.White, onBackground = Color.White, secondary = Color.White),
    content = content
)
