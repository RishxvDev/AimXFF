package com.aimx.capture

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.aimx.MainActivity
import com.aimx.R
import com.aimx.analysis.*
import com.aimx.data.AimXState
import com.aimx.data.Live
import com.aimx.data.Store
import com.aimx.overlay.Overlay

/**
 * Foreground service owning the MediaProjection session. Frames are processed in memory on a
 * background thread, throttled to the configured FPS, and immediately discarded. Nothing leaves the device.
 */
class CaptureService : Service() {
    companion object {
        const val ACTION_START = "aimx.START"
        const val ACTION_STOP = "aimx.STOP"
        const val ACTION_PAUSE = "aimx.PAUSE"
        const val ACTION_RESUME = "aimx.RESUME"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CH = "aimx_capture"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var engine: AimEngine? = null
    private var overlay: Overlay? = null
    private var cfg = AimSettings()
    private val detector = EnemyDetector()
    private var lastRun = 0L
    private var active = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_START -> start(i)
            ACTION_PAUSE -> setPaused(true)
            ACTION_RESUME -> setPaused(false)
            ACTION_STOP -> stop()
        }
        return START_NOT_STICKY
    }

    private fun start(i: Intent) {
        if (active) return
        cfg = Store.settings(this)
        // Must be a foreground service (type mediaProjection) BEFORE obtaining the projection (Android 14+).
        ServiceCompat.startForeground(this, 1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = IntentCompat.getParcelableExtra(i, EXTRA_DATA, Intent::class.java)
        val code = i.getIntExtra(EXTRA_CODE, 0)
        if (data == null) { stopSelf(); return }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        active = true

        val t = HandlerThread("aimx-analysis").also { it.start() }
        thread = t
        val handler = Handler(t.looper)
        // Required on Android 14+: register callback before creating the VirtualDisplay.
        proj.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stop() } }, handler)

        // Free Fire is landscape-only, so capture is always landscape and downscaled for low CPU/battery.
        val m = resources.displayMetrics
        val w = 640
        val h = (w * minOf(m.widthPixels, m.heightPixels).toFloat() / maxOf(m.widthPixels, m.heightPixels)).toInt()
        val rd = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = rd
        display = proj.createVirtualDisplay("AimX", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, handler)

        engine = AimEngine(cfg)
        if (cfg.overlay && Settings.canDrawOverlays(this)) {
            overlay = Overlay(this) { setPaused(!AimXState.paused.value) }.also { o ->
                Handler(mainLooper).post { o.show() }
            }
        }
        AimXState.paused.value = false
        AimXState.running.value = true

        rd.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.elapsedRealtime()
                if (AimXState.paused.value || now - lastRun < 1000L / cfg.fps) return@setOnImageAvailableListener
                lastRun = now
                val plane = img.planes[0]
                val cx = w / 2f
                val cy = h * (0.5f + cfg.crosshairY)
                val det = detector.detect(plane.buffer, plane.rowStride, w, h, cx.toInt())
                val eng = engine ?: return@setOnImageAvailableListener
                val res = eng.onFrame(det, cx, cy, now)
                AimXState.live.value = Live(res.level, res.offset, eng.alignedPct, eng.avgReaction)
                overlay?.update(res.level, false)
            } finally { img.close() }
        }, handler)
    }

    private fun setPaused(p: Boolean) {
        if (!active) return
        AimXState.paused.value = p
        if (p) AimXState.live.value = Live()
        overlay?.update(HeadLevel.NONE, p)
        getSystemService(NotificationManager::class.java).notify(1, notification())
    }

    private fun stop() {
        if (!active) { stopSelf(); return }
        active = false
        reader?.setOnImageAvailableListener(null, null)
        display?.release(); reader?.close()
        projection?.stop()
        thread?.quitSafely()
        engine?.let { Store.add(this, it.summary()) }
        Handler(mainLooper).post { overlay?.hide() }
        AimXState.running.value = false
        AimXState.paused.value = false
        AimXState.live.value = Live()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (active) stop(); super.onDestroy() }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "AimX analysis", NotificationManager.IMPORTANCE_LOW))
        fun pi(a: String, rc: Int) = PendingIntent.getService(this, rc,
            Intent(this, CaptureService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val paused = AimXState.paused.value
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_aimx)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            .setContentTitle("AimX analysis " + if (paused) "paused" else "running")
            .setContentText("Screen is analysed on-device only")
            .setOngoing(true)
            .addAction(0, if (paused) "Resume" else "Pause", pi(if (paused) ACTION_RESUME else ACTION_PAUSE, 1))
            .addAction(0, "Stop", pi(ACTION_STOP, 2))
            .build()
    }
}
