package com.aimx.analysis

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {
    // headY = barBottom + headOffset * barWidth = 50 + 0.4 * 50 = 70
    private val det = Detection(cx = 100f, barBottom = 50f, barWidth = 50f)

    @Test fun alignedWhenCrosshairAtHeadLevel() {
        val r = AimEngine(AimSettings()).onFrame(det, 100f, 70f, 1000)
        assertEquals(HeadLevel.ALIGNED, r.level)
    }

    @Test fun aboveWhenCrosshairHigherThanHead() {
        val r = AimEngine(AimSettings()).onFrame(det, 100f, 40f, 1000)
        assertEquals(HeadLevel.ABOVE, r.level)
    }

    @Test fun belowWhenCrosshairLowerThanHead() {
        val r = AimEngine(AimSettings()).onFrame(det, 100f, 100f, 1000)
        assertEquals(HeadLevel.BELOW, r.level)
    }

    @Test fun noneWhenNoDetectionOrOffTarget() {
        val e = AimEngine(AimSettings())
        assertEquals(HeadLevel.NONE, e.onFrame(null, 100f, 70f, 1000).level)
        assertEquals(HeadLevel.NONE, e.onFrame(det, 300f, 70f, 1100).level)
        assertEquals(0, e.summary().samples)
    }

    @Test fun reactionTimeIsMeasuredUntilFirstAlignedFrame() {
        val e = AimEngine(AimSettings())
        e.onFrame(det, 100f, 40f, 1000)   // target appears, crosshair above
        e.onFrame(det, 100f, 70f, 1300)   // aligned 300 ms later
        assertEquals(300, e.avgReaction)
    }

    @Test fun summaryPercentagesAddUp() {
        val e = AimEngine(AimSettings())
        e.onFrame(det, 100f, 70f, 1000)
        e.onFrame(det, 100f, 40f, 1100)
        e.onFrame(det, 100f, 100f, 1200)
        e.onFrame(det, 100f, 70f, 1300)
        val s = e.summary()
        assertEquals(4, s.samples)
        assertEquals(50f, s.alignedPct, 0.01f)
        assertEquals(25f, s.abovePct, 0.01f)
        assertEquals(25f, s.belowPct, 0.01f)
    }

    @Test fun recommenderNeedsEnoughData() {
        val few = listOf(SessionSummary(0, 0, 30, 50f, 25f, 25f, 300f, 0.2f, 0f))
        assertFalse(Recommender.advise(few).enoughData)
    }

    @Test fun recommenderLowersSensitivityWhenOvershootingAbove() {
        val s = listOf(SessionSummary(0, 0, 100, 20f, 60f, 20f, 300f, 0.2f, -0.5f))
        val a = Recommender.advise(s)
        assertTrue(a.enoughData)
        assertEquals(-10, a.changePct)
    }

    @Test fun recommenderRaisesSensitivityWhenStoppingBelow() {
        val s = listOf(SessionSummary(0, 0, 100, 20f, 20f, 60f, 300f, 0.2f, 0.5f))
        assertEquals(10, Recommender.advise(s).changePct)
    }
}
