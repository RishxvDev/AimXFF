# AimX privacy

- Screen capture uses Android MediaProjection and only starts after you accept the system prompt.
- Frames are analysed in memory on your device and discarded immediately. They are never saved or uploaded.
- The app has no INTERNET permission, so it cannot send data anywhere.
- Only numeric session summaries (percentages, reaction time) and your settings are stored locally.
  Settings > "Delete all training data" removes them.
- AimX never sends touch input, injects code, or reads game memory. It cannot control any game.
